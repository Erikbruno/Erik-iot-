# ---------------------------------------------------------
# SISTEMA SIMPLES DE MONITORAMENTO DE GADO EM CONFINAMENTO
# Simulação em Python (funciona em qualquer computador)
# ---------------------------------------------------------
import random
import time

# ---------------------------------------------------------
# FUNÇÕES DOS SENSORES (SIMULAÇÃO)
# ---------------------------------------------------------

def ler_peso_racao():
    """Simula leitura da célula de carga (HX711)."""
    return random.uniform(40.0, 50.0)  # kg no cocho

def ler_fluxo_agua():
    """Simula leitura do sensor YF-S201 em litros."""
    return random.uniform(0.0, 5.0)  # litros consumidos no intervalo

def ler_pir():
    """Simula detecção de presença do gado."""
    return random.choice([0, 1])

def ler_nivel_bebedouro():
    """Simula nível do bebedouro (boia)."""
    return random.choice([0, 1])  # 1 = água OK / 0 = sem água

def ler_dht22():
    """Simula temperatura e umidade do ar."""
    temp = random.uniform(20, 38)
    umid = random.uniform(30, 90)
    return temp, umid

# ---------------------------------------------------------
# CÁLCULO DO THI (Índice de Calor)
# ---------------------------------------------------------

def calcular_thi(temp, umid):
    # Fórmula padrão
    return temp - (0.55 - 0.0055 * umid) * (temp - 14.5)

# ---------------------------------------------------------
# AVALIAÇÃO DO THI
# ---------------------------------------------------------

def classificar_thi(thi):
    if thi <= 74:
        return "NORMAL"
    elif 75 <= thi <= 78:
        return "ATENÇÃO"
    elif 79 <= thi <= 83:
        return "ALERTA"
    else:
        return "CRÍTICO"

# ---------------------------------------------------------
# SISTEMA COMPLETO (Nó do Cocho + Nó Ambiental)
# ---------------------------------------------------------

def sistema_monitoramento():
    peso_anterior = ler_peso_racao()

    while True:
        print("\n--- CICLO DE MONITORAMENTO ---")

        # ------------------- NÓ DO COCHO -------------------
        peso_atual = ler_peso_racao()
        consumo_racao = max(0, peso_anterior - peso_atual)
        peso_anterior = peso_atual

        consumo_agua = ler_fluxo_agua()
        presenca = ler_pir()
        nivel_bebedouro = ler_nivel_bebedouro()

        # ------------------- NÓ AMBIENTAL -------------------
        temp, umid = ler_dht22()
        thi = calcular_thi(temp, umid)
        classificacao = classificar_thi(thi)

        # ------------------- EXIBIÇÃO -----------------------
        print(f"Ração consumida:     {consumo_racao:.2f} kg")
        print(f"Água consumida:      {consumo_agua:.2f} L")
        print(f"Presença no cocho:   {'SIM' if presenca else 'NÃO'}")
        print(f"Nível bebedouro:     {'OK' if nivel_bebedouro else 'SEM ÁGUA'}")
        print(f"Temperatura:         {temp:.1f} °C")
        print(f"Umidade:             {umid:.1f} %")
        print(f"THI:                 {thi:.1f} ({classificacao})")

        # ------------------- ALERTAS ------------------------
        if consumo_racao < 1:
            print("⚠ ALERTA: Consumo de ração abaixo do esperado!")

        if consumo_agua < 0.5:
            print("⚠ ALERTA: Queda no consumo de água!")

        if nivel_bebedouro == 0:
            print("⚠ ALERTA: Bebedouro sem água!")

        if thi >= 79:
            print("🔥 ALERTA: Estresse térmico!")

        # ------------------- INTERVALO ----------------------
        time.sleep(3)  # reduzir tempo aqui se quiser mais rápido


# ---------------------------------------------------------
# INICIAR SISTEMA
# ---------------------------------------------------------

sistema_monitoramento()

# Este programa simula:
#
#  1= Nó do Cocho
#
# consumo de ração
#
# consumo de água
#
# sensor PIR
#
# nível do bebedouro
#
# alertas de consumo baixo
#
#  2= Nó Ambiental
#
# temperatura e umidade
#
# cálculo do THI
#
# classificação do risco (normal / atenção / alerta / crítico)
#
# alerta de estresse térmico